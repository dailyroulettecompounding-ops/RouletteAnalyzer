package org.openroulette.analyzer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF10141C)
private val Panel = Color(0xFF202733)
private val Panel2 = Color(0xFF293241)
private val Gold = Color(0xFFD8B46A)
private val Red = Color(0xFFD83E48)
private val Green = Color(0xFF16A36A)
private val Black = Color(0xFF303641)
private val Muted = Color(0xFFAAB4C4)
private val redNumbers = setOf(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36)
private val wheelOrder = listOf(0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26)

private fun col(n: Int) = if (n == 0) 0 else (n - 1) % 3 + 1
private fun dozen(n: Int) = if (n == 0) 0 else (n - 1) / 12 + 1
private fun colorName(n: Int) = when { n == 0 -> "Green"; n in redNumbers -> "Red"; else -> "Black" }
private fun ballColor(n: Int) = when { n == 0 -> Green; n in redNumbers -> Red; else -> Black }

data class Prediction(val status: String, val columns: List<Int>, val latest: Int?, val sixth: Int?)
data class PredictionRecord(val columns: List<Int>, val triggerLatest: Int, val triggerSixth: Int, val actual: Int, val hit: Boolean)

private fun calculatePrediction(newestFirst: List<Int>): Prediction {
    if (newestFirst.size < 6) return Prediction("WAITING · NEED 6 SPINS", emptyList(), newestFirst.firstOrNull(), null)
    val latest = newestFirst[0]
    val sixth = newestFirst[5]
    val a = col(latest)
    val b = col(sixth)
    if (a == 0 || b == 0) return Prediction("WAITING · ZERO IN COMPARISON", emptyList(), latest, sixth)
    if (a == b) return Prediction("WAITING · SAME COLUMN", emptyList(), latest, sixth)
    return Prediction("PREDICTION ACTIVE", listOf(a, b), latest, sixth)
}

private fun isSplit(a: Int, b: Int): Boolean {
    if (a == 0 || b == 0) return false
    val ra = (a - 1) / 3
    val rb = (b - 1) / 3
    val ca = (a - 1) % 3
    val cb = (b - 1) % 3
    return (ra == rb && kotlin.math.abs(ca - cb) == 1) ||
           (ca == cb && kotlin.math.abs(ra - rb) == 1)
}

private fun loadSpins(context: Context): List<Int> {
    return try {
        val raw = context.getSharedPreferences("roulette_analyzer", Context.MODE_PRIVATE).getString("spins", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getInt(it) }.filter { it in 0..36 }
    } catch (_: Exception) { emptyList() }
}

private fun saveSpins(context: Context, spins: List<Int>) {
    val arr = JSONArray()
    spins.forEach { arr.put(it) }
    context.getSharedPreferences("roulette_analyzer", Context.MODE_PRIVATE)
        .edit().putString("spins", arr.toString()).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RouletteAnalyzerApp() }
    }
}

@Composable
fun RouletteAnalyzerApp() {
    val context = LocalContext.current
    var spins by remember { mutableStateOf(loadSpins(context)) } // newest first
    var records by remember { mutableStateOf(loadRecords(context)) }
    var selected by remember { mutableIntStateOf(17) }
    var tab by remember { mutableStateOf("Home") }
    val prediction = remember(spins) { calculatePrediction(spins) }
    val counts = remember(spins) { IntArray(37).also { a -> spins.forEach { a[it]++ } } }

    fun updateSpins(next: List<Int>) {
        spins = next
        saveSpins(context, next)
    }
    fun addSpin(n: Int) {
        val prior = calculatePrediction(spins)
        if (prior.columns.isNotEmpty()) {
            val hit = col(n) in prior.columns
            records = listOf(PredictionRecord(prior.columns, prior.latest ?: 0, prior.sixth ?: 0, n, hit)) + records
            saveRecords(context, records)
        }
        updateSpins(listOf(n) + spins)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Gold, secondary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(14.dp)) {
                Header()
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Home", "Predictions", "Analysis", "History").forEach { name ->
                        val active = tab == name
                        Surface(
                            modifier = Modifier.weight(1f).clickable { tab = name },
                            color = if (active) Gold else Panel,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(name, Modifier.padding(vertical = 10.dp), color = if (active) Bg else Muted,
                                fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                when (tab) {
                    "Home" -> HomeScreen(spins, prediction, selected, { selected = it }, ::addSpin, { updateSpins(spins.drop(1)) }, { updateSpins(emptyList()); records = emptyList(); saveRecords(context, records) })
                    "Predictions" -> PredictionsScreen(spins, prediction, counts)
                    "Analysis" -> AnalysisScreen(spins, counts)
                    else -> HistoryScreen(spins, records, { updateSpins(spins.drop(1)) }, {
                        val csv = buildString {
                            append("order_from_latest,number,color,column,dozen\n")
                            spins.forEachIndexed { i, n -> append("${i+1},$n,${colorName(n)},${if(col(n)==0) "Zero" else col(n)},${if(dozen(n)==0) "Zero" else dozen(n)}\n") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/csv"
                            putExtra(Intent.EXTRA_SUBJECT, "Roulette Analyzer spin history")
                            putExtra(Intent.EXTRA_TEXT, csv)
                        }
                        context.startActivity(Intent.createChooser(send, "Export spin history"))
                    })
                }
                Spacer(Modifier.height(8.dp))
                Text("Independent random spins · Analysis is descriptive, not a guarantee.", color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}

private fun loadRecords(context: Context): List<PredictionRecord> = try {
    val raw = context.getSharedPreferences("roulette_analyzer", Context.MODE_PRIVATE).getString("records", "[]") ?: "[]"
    val a = JSONArray(raw)
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        val c = o.getJSONArray("columns")
        PredictionRecord((0 until c.length()).map { c.getInt(it) }, o.getInt("latest"), o.getInt("sixth"), o.getInt("actual"), o.getBoolean("hit"))
    }
} catch (_: Exception) { emptyList() }

private fun saveRecords(context: Context, records: List<PredictionRecord>) {
    val a = JSONArray()
    records.forEach { r ->
        val c = JSONArray().also { x -> r.columns.forEach(x::put) }
        a.put(JSONObject().put("columns", c).put("latest", r.triggerLatest).put("sixth", r.triggerSixth).put("actual", r.actual).put("hit", r.hit))
    }
    context.getSharedPreferences("roulette_analyzer", Context.MODE_PRIVATE).edit().putString("records", a.toString()).apply()
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("ROULETTE ANALYZER", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Text("EUROPEAN ROULETTE · SINGLE ZERO", color = Muted, fontSize = 10.sp)
        }
        Text("OPEN SOURCE · V1.1", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HomeScreen(
    spins: List<Int>, prediction: Prediction, selected: Int,
    onSelect: (Int) -> Unit, onAdd: (Int) -> Unit, onUndo: () -> Unit, onClear: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("TOTAL SPINS", spins.size.toString(), Modifier.weight(1f))
                StatCard("LATEST", spins.firstOrNull()?.toString() ?: "—", Modifier.weight(1f))
                StatCard("ZERO", spins.count { it == 0 }.toString(), Modifier.weight(1f))
            }
        }
        item {
            PanelCard {
                Text("MANUAL SPIN ENTRY", color = Gold, fontWeight = FontWeight.Bold)
                Text("Selected number: $selected", color = Color.White, fontSize = 18.sp)
                NumberGrid(selected, onSelect)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onAdd(selected) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("ADD SPIN") }
                    OutlinedButton(onClick = onUndo) { Text("UNDO") }
                    OutlinedButton(onClick = onClear) { Text("CLEAR") }
                }
            }
        }
        item { PredictionCard(prediction) }
        item {
            PanelCard {
                Text("RECENT SPINS · NEWEST FIRST", color = Gold, fontWeight = FontWeight.Bold)
                if (spins.isEmpty()) Text("No results entered.", color = Muted)
                else Text(spins.take(30).joinToString("  ·  "), color = Color.White)
            }
        }
    }
}

@Composable
private fun NumberGrid(selected: Int, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (row in 0..6) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (n in row * 6..minOf(row * 6 + 5, 36)) {
                    Box(
                        Modifier.weight(1f).height(39.dp)
                            .background(if (n == selected) Gold else ballColor(n), RoundedCornerShape(8.dp))
                            .clickable { onSelect(n) },
                        contentAlignment = Alignment.Center
                    ) { Text(n.toString(), color = if (n == selected) Bg else Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun PredictionCard(p: Prediction) {
    PanelCard {
        Text("CUSTOM TWO-COLUMN STRATEGY", color = Gold, fontWeight = FontWeight.Bold)
        Text(p.status, color = if (p.columns.isNotEmpty()) Green else Gold, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("LATEST", color = Muted, fontSize = 10.sp)
                Text(p.latest?.let { "$it · ${if(col(it)==0) "ZERO" else "COLUMN ${col(it)}"}" } ?: "—")
            }
            Column {
                Text("6TH PREVIOUS", color = Muted, fontSize = 10.sp)
                Text(p.sixth?.let { "$it · ${if(col(it)==0) "ZERO" else "COLUMN ${col(it)}"}" } ?: "—")
            }
        }
        if (p.columns.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                p.columns.forEach { c ->
                    Surface(color = Gold, shape = RoundedCornerShape(9.dp)) {
                        Text("COLUMN $c", Modifier.padding(horizontal = 17.dp, vertical = 11.dp), color = Bg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else Text("No active selection. The rule recalculates after every entered result.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun PredictionsScreen(spins: List<Int>, p: Prediction, counts: IntArray) {
    val top = (0..36).sortedWith(compareByDescending<Int> { counts[it] }.thenBy { it }).take(10)
    val cold = (0..36).sortedWith(compareBy<Int> { counts[it] }.thenBy { it }).take(10)
    val latest = spins.firstOrNull()
    val neighbours = latest?.let {
        val idx = wheelOrder.indexOf(it)
        (-2..2).map { offset -> wheelOrder[(idx + offset + 37) % 37] }
    } ?: emptyList()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PredictionCard(p) }
        item {
            PanelCard {
                Text("NUMBER RANKINGS · FREQUENCY ONLY", color = Gold, fontWeight = FontWeight.Bold)
                Text("Most frequent in recorded history", color = Muted, fontSize = 11.sp)
                NumberRanking(top, counts)
                Divider(color = Panel2)
                Text("Least frequent in recorded history", color = Muted, fontSize = 11.sp)
                NumberRanking(cold, counts)
            }
        }
        item {
            PanelCard {
                Text("WHEEL NEIGHBOURS OF LATEST RESULT", color = Gold, fontWeight = FontWeight.Bold)
                if (neighbours.isEmpty()) Text("Add a spin to calculate neighbours.", color = Muted)
                else Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    neighbours.forEachIndexed { i, n ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Ball(n)
                            Text(if (i == 2) "Latest" else "Wheel", color = Muted, fontSize = 9.sp)
                        }
                    }
                }
                Text("European wheel order is used; neighbours are not table-adjacent numbers.", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun NumberRanking(numbers: List<Int>, counts: IntArray) {
    numbers.forEach { n ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Ball(n, 30)
            Spacer(Modifier.width(8.dp))
            Text("Number $n", Modifier.weight(1f), color = Color.White)
            Text("${counts[n]} hits", color = Gold)
        }
    }
}

@Composable
private fun AnalysisScreen(spins: List<Int>, counts: IntArray) {
    val red = spins.count { it in redNumbers }
    val black = spins.count { it != 0 && it !in redNumbers }
    val green = spins.count { it == 0 }
    val even = spins.count { it != 0 && it % 2 == 0 }
    val odd = spins.count { it % 2 == 1 }
    val dozens = (1..3).map { d -> spins.count { dozen(it) == d } }
    val columns = (1..3).map { c -> spins.count { col(it) == c } }
    val streets = (0..11).map { r -> spins.count { it != 0 && (it - 1) / 3 == r } }
    val splitPairs = buildList {
        for (n in 1..36) {
            val row = (n - 1) / 3
            val c = (n - 1) % 3
            if (c < 2) add(n to n + 1)
            if (row < 11) add(n to n + 3)
        }
    }.sortedByDescending { (a,b) -> counts[a] + counts[b] }.take(10)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PanelCard {
                Text("RED / BLACK / GREEN", color = Gold, fontWeight = FontWeight.Bold)
                StatLine("Red", red); StatLine("Black", black); StatLine("Green (zero)", green)
                Divider(color = Panel2)
                Text("ODD / EVEN (zero excluded)", color = Gold, fontWeight = FontWeight.Bold)
                StatLine("Odd", odd); StatLine("Even", even)
            }
        }
        item {
            PanelCard {
                Text("DOZENS", color = Gold, fontWeight = FontWeight.Bold)
                dozens.forEachIndexed { i, v -> StatLine("${i+1}${listOf("st","nd","rd")[i]} dozen", v) }
                Divider(color = Panel2)
                Text("COLUMNS", color = Gold, fontWeight = FontWeight.Bold)
                columns.forEachIndexed { i, v -> StatLine("Column ${i+1}", v) }
            }
        }
        item {
            PanelCard {
                Text("STREETS (TABLE ROWS)", color = Gold, fontWeight = FontWeight.Bold)
                streets.forEachIndexed { i, v -> StatLine("Street ${i+1} · ${i*3+1}–${i*3+3}", v) }
            }
        }
        item {
            PanelCard {
                Text("SPLIT-BET ANALYSIS", color = Gold, fontWeight = FontWeight.Bold)
                Text("Top table-adjacent split pairs ranked by combined recorded hits.", color = Muted, fontSize = 10.sp)
                splitPairs.forEach { (a,b) -> StatLine("$a / $b", counts[a] + counts[b]) }
            }
        }
    }
}

@Composable
private fun HistoryScreen(spins: List<Int>, records: List<PredictionRecord>, onUndo: () -> Unit, onExport: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PanelCard {
                Text("SPIN HISTORY", color = Gold, fontWeight = FontWeight.Bold)
                Text("${spins.size} saved spins · newest first", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onUndo, enabled = spins.isNotEmpty()) { Text("UNDO LATEST") }
                    Button(onClick = onExport, enabled = spins.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("EXPORT CSV", color = Bg) }
                }
                if (spins.isEmpty()) Text("No history yet.", color = Muted)
                else spins.take(200).forEachIndexed { i, n ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("#${i+1}", color = Muted, modifier = Modifier.width(48.dp))
                        Ball(n, 29)
                        Text("  ${colorName(n)} · ${if(col(n)==0) "Zero" else "Column ${col(n)}"} · ${if(dozen(n)==0) "No dozen" else "Dozen ${dozen(n)}"}", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            PanelCard {
                Text("PREDICTION PERFORMANCE", color = Gold, fontWeight = FontWeight.Bold)
                val hits = records.count { it.hit }
                val misses = records.size - hits
                val rate = if (records.isEmpty()) 0 else hits * 100 / records.size
                StatLine("Settled predictions", records.size)
                StatLine("Hits", hits)
                StatLine("Misses", misses)
                StatLine("Hit rate", "$rate%")
                Text("A hit means the next result landed in either selected column. This is historical tracking, not a forecast guarantee.", color = Muted, fontSize = 10.sp)
                records.take(100).forEach { r ->
                    StatLine("C${r.columns.joinToString(" + C")} · result ${r.actual}", if(r.hit) "HIT" else "MISS")
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text(label, color = Muted, fontSize = 9.sp)
            Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp), content = content)
    }
}

@Composable
private fun Ball(n: Int, size: Int = 34) {
    Box(Modifier.size(size.dp).background(ballColor(n), CircleShape), contentAlignment = Alignment.Center) {
        Text(n.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun StatLine(label: String, value: Any) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 12.sp)
        Text(value.toString(), color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
